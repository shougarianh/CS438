function costVersusLambda(lambda_cost)

	figure("name", "Cost Vs. Lambda"); % open a new figure window
	hold on;
	
	color = ['r-' 'g-' 'b-' 'k-' 'r*' 'g*' 'b*' 'k*'];
	
	for	i = 1:rows(lambda_cost)
	
		plot((0:length(lambda_cost(i, :))-1) , lambda_cost(i, :), color(i), 'MarkerSize', 10);
	
	end
	
	set(gca, 'linewidth', 2, 'fontsize', 22);
	xlabel('Lambda'); % Set the x-axis label
	ylabel('cost'); % Set the y-axis label

end