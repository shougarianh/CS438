function plotLearningCurve(learning_cost)

	figure("name", "Learning Curve"); % open a new figure window
	hold on;
	
	color = ['r-' 'g-' 'b-' 'k-' 'r*' 'g*' 'b*' 'k*'];
	
	for	i = 1:rows(learning_cost)
	
		plot((0:length(learning_cost(i, :))-1) * 100, learning_cost(i, :), color(i), 'MarkerSize', 10);
	
	end
	
	set(gca, 'linewidth', 2, 'fontsize', 22);
	xlabel('training examples'); % Set the x-axis label
	ylabel('cost'); % Set the y-axis label

end