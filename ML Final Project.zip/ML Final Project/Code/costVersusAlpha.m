function costVersusAlpha(alpha_cost)

	figure("name", "Cost Vs. alpha"); % open a new figure window
	hold on;
	
	color = ['r-' 'g-' 'b-' 'k-' 'r*' 'g*' 'b*' 'k*'];
	
	for	i = 1:rows(alpha_cost)
	
		plot((0:length(alpha_cost(i, :))-1) , alpha_cost(i, :), color(i), 'MarkerSize', 10);
	
	end
	
	set(gca, 'linewidth', 2, 'fontsize', 22);
	xlabel('alpha'); % Set the x-axis label
	ylabel('cost'); % Set the y-axis label

end