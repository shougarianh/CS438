function D = backPropagateNN(Theta, A, Y, lambda)

    	L = length(A);
	m = columns(Y);
	bias = ones(1, m);
	
	D = cell(size(Theta));

	d = A{L} - Y;

	for l = (L-1):-1:1

		D{l} = d * [bias; A{l}]';
		D{l}(:, 2:end) += lambda * Theta{l}(:,2:end);
		D{l} /= m;

		if (l > 1)
			d = (Theta{l}'(2:end,:) * d) .* (A{l} .* (1 - A{l}));
		end
	end

end