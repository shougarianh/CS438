function X_MATRIX = loadData(images)
    X_MATRIX = [images ones(rows(images), 1)];
end