function cost = J(theta, X, y)
    m = rows(X);
    cost = sum(-ln(h(theta, X)) .* y - ln(1 - h(theta, X)) .* (1 - y)) / m;
end