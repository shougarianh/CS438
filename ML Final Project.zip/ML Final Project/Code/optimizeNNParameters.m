function optimizeNNParameters(Theta, input_matrix, X_Validation, Y, Y_validation)

lambda = 30;
alpha = 2;
maxIter = 50;

printf("Producing cost Vs. alpha graph, press enter to start");
pause;

alpha_cost = [];
alpha_validation_cost = [];
for i = 0 : 1 : 15
    [Theta1, costs] = gradientDescentNN(Theta, input_matrix, Y, lambda, i, maxIter);
    est_alpha_train = forwardPropagateNN(Theta1, input_matrix){end};
    alpha_cost = [alpha_cost JNN(Theta1, est_alpha_train, Y, 0)];
    est_alpha_validation = forwardPropagateNN(Theta1, X_Validation){end};
    alpha_validation_cost = [alpha_validation_cost JNN(Theta1, est_alpha_validation, Y_validation, 0)];
end

alpha_cost = [alpha_cost ; alpha_validation_cost];
costVersusAlpha(alpha_cost);


printf("Producing cost Vs. lambda graph, press enter to start");
pause;

lambda_cost = [];
lambda_validation_cost = [];
for i = 0 : 1 : 30
    [Theta1, costs] = gradientDescentNN(Theta, input_matrix, Y, i, alpha, maxIter);
    est_lambda_train = forwardPropagateNN(Theta1, input_matrix){end};
    lambda_cost = [lambda_cost JNN(Theta1, est_lambda_train, Y, 0)];
    est_lambda_validation = forwardPropagateNN(Theta1, X_Validation){end};
    lambda_validation_cost = [lambda_validation_cost JNN(Theta1, est_lambda_validation, Y_validation, 0)];
end

lambda_cost = [lambda_cost ; lambda_validation_cost];
costVersusLambda(lambda_cost);


printf("Producing learning curve, press enter to start");
pause;
training_cost = []; % will hold all of the learning costs
validation_cost = [];


for i = 100 : 100 : 1000%rows(input_matrix)
    thisY = Y(:, 1 : i); % this is y for the training set
    train_mat = input_matrix(1 : i, :); % this is a matrix of size m
    [Theta1, costs] = gradientDescentNN(Theta, train_mat, thisY, lambda, alpha, maxIter);
    est = forwardPropagateNN(Theta1, train_mat){end};
    training_cost = [training_cost JNN(Theta1, est, thisY, 0)];
    est_validation = forwardPropagateNN(Theta1, X_Validation){end};
    validation_cost = [validation_cost JNN(Theta1, est_validation, Y_validation, 0)];
end

training_cost = [training_cost ; validation_cost];
plotLearningCurve(training_cost);

end