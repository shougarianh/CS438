pkg load image;

printf("Loading data: this may take a minute...")
input_matrix = getInputMatrixNN();
expected_vals = getYNN();
sel = randperm(size(input_matrix, 1));
X_test = input_matrix(sel(7001:10000), :);
X_Validation = input_matrix(sel(10001:end), :);
y_validation = expected_vals(sel(10001:end));
input_matrix = input_matrix(sel(1:7000), :);
y_test = expected_vals(sel(7001:10000));
y = expected_vals(sel(1:7000));



% Do the training on the training set

m = rows(input_matrix);
n1 = columns(input_matrix);

n = [n1, 30,  max(y)];
Y = prepareYNN(y);
Theta = initThetaNN(n);
Y_test =  prepareYNN(y_test);
Y_validation = prepareYNN(y_validation);


lambda = 36;
alpha = 2;
maxIter = 500;

%%%%%%%%%% UNCOMENT THIS TO SEE TUNING GRAPHS %%%%%%%%%%%%%%%%%%%%%%
%optimizeNNParameters(Theta, input_matrix, X_Validation, Y, Y_validation);


printf('\nHere are some samples from the training dataset.\nPress enter to start training.');
pause;



[Theta, costs] = gradientDescentNN(Theta, input_matrix, Y, lambda, alpha, maxIter);
plotCost(costs);


pause;

% Print training and test accuracy

est = forwardPropagateNN(Theta, input_matrix){end};
[_, pred] = max(est);
pred = pred';
correct = sum(pred == y);
accuracy = correct / rows(y);
printf("Training accuracy = %f\n", accuracy);
est_test = forwardPropagateNN(Theta, X_test){end};
[_, pred] = max(est_test);
pred = pred';
correct = sum(pred == y_test);
accuracy = correct / rows(y_test);
printf("Test accuracy = %f\n", accuracy);

pause;



