function [x] = ln(x)

	x = fixInf(log(x));

end
