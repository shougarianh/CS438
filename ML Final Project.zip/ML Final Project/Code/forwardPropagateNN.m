function activation = forwardPropagateNN(Theta, X)
    numLayers = 2;
    activation = cell(numLayers + 1, 1);
    activation{1} = X';
    for l = 2 : numLayers + 1
       the_layer = Theta{l - 1};
       act_layer = [ones(1, columns(activation{l - 1})) ; activation{l - 1}];
       activation{l} = g(the_layer * act_layer);
    end

end