function [err] = error(theta, X, y)

	err = h(theta, X) - y;

end