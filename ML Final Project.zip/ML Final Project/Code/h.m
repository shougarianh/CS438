function estimates = h(theta, X)
    estimates = g(X * theta);
end