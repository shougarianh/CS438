function [letter, accuracy] = testGetLogisticLetter(test_X_matrix, theta_matrix)
    letters = ["A" "B" "C" "D" "E" "F" "G" "H" "I" "J" "K" "L" "M" "N" "O" "P" "Q" "R" "S" "T" "U" "V" "W" "X" "Y" "Z"];
    biggest_accuracy = 0;
    index = 1;

    for i = 1 : 26
        theta = theta_matrix(i, :)';
        predictions = h(theta, test_X_matrix);
        [accuracy] = returnLogisticAccuracy(predictions);
        if (accuracy > biggest_accuracy)
            biggest_accuracy = accuracy;
            index = i;
        end
    end
    letter = letters(index);
    accuracy = biggest_accuracy;

end