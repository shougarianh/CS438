function [theta, costs] = runLogisticGradient(X_MATRIX)
    len_img_2 = rows(X_MATRIX) - 50;
    y = [(ones(len_img_2, 1)) ; zeros(len_img_2/2, 1)];

    thetas = zeros(columns(X_MATRIX), 1);
    %estimates = h(thetas, X_MATRIX);
    %d = JDerivative(thetas, X_MATRIX, y);

    %  This function will return theta and the cost history
    alpha = 0.5;
    maxIter = 500;
    [theta, costs] = gradientDescent(thetas, X_MATRIX, y, alpha, maxIter);

end