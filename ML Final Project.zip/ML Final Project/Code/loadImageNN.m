function images = loadImageNN(directory, imagefiles)
    numfiles = length(imagefiles);
    for i = 1 : 500
        image = imread(strcat(directory, imagefiles(i).name));
        image = imcomplement(imresize(image, [90, 90]));
        image = image(:, :, 1)';
        images(i, :) = image(:)';
    end
end